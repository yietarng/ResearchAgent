import sys, pathlib, warnings
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

# Suppress LangGraph's pending deprecation warning about allowed_objects
# (fires at import time inside langgraph internals; not actionable from user code)
warnings.filterwarnings("ignore", message="The default value of `allowed_objects`")

from dotenv import load_dotenv
load_dotenv()          # finds .env in the same directory as this script

from research_agent import run_research

answer = run_research("The new development of reinforcement pre-training after 2025")
print(answer)
