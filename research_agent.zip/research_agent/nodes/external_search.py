from __future__ import annotations

import functools
import re
from typing import Any

from langgraph.prebuilt import create_react_agent

from research_agent.config import ResearchAgentConfig
from research_agent.memory.ltm import LTMStore
from research_agent.memory.stm import STMStore
from research_agent.prompts import RESEARCH_PROMPT
from research_agent.state import AgentState
from research_agent.tools.ltm_tools import build_ltm_tools
from research_agent.tools.stm_tools import build_stm_tools
from research_agent.tools.web_search import build_web_search_tool

_URL_RE = re.compile(r'https?://[^\s,)"\'>]+')


def external_search(
    state: AgentState,
    *,
    llm: Any,
    ltm_store: LTMStore,
    ra_config: ResearchAgentConfig | None = None,
) -> dict:
    """Run a ReAct agent loop with web_search, LTM, and STM tools."""
    api_key_env = ra_config.tavily_api_key_env if ra_config else "TAVILY_API_KEY"
    web_tool = build_web_search_tool(api_key_env=api_key_env)
    retrieve_ltm, store_ltm = build_ltm_tools(ltm_store)
    read_stm, write_stm, stm_writes = build_stm_tools(state)
    agent = create_react_agent(llm, [web_tool, retrieve_ltm, store_ltm, read_stm, write_stm])

    stm_summary = STMStore.format_for_prompt(state)
    ltm_summary = "\n".join(
        entry.get("content", "") for entry in state.get("ltm_context", [])
    )
    system_message = (
        RESEARCH_PROMPT
        + f"\n\nShort-term memory:\n{stm_summary}"
        + f"\n\nLong-term memory:\n{ltm_summary}"
    )

    result = agent.invoke({"messages": [
        {"role": "system", "content": system_message},
        {"role": "user", "content": state["user_query"]},
    ]})

    citations: list[str] = []
    retrieved_docs: list[str] = []
    for msg in result["messages"]:
        content = getattr(msg, "content", "")
        msg_type = getattr(msg, "type", "")
        if msg_type in ("ai", "tool"):
            citations.extend(_URL_RE.findall(content))
        if content and msg_type == "tool":
            retrieved_docs.append(content[:500])

    return {
        "retrieved_docs": retrieved_docs,
        "citations": list(dict.fromkeys(citations)),
        "stm_notes": stm_writes,
        "intermediate_notes": ["[Search] Agent completed external search."],
    }


def build_external_search(llm: Any, ltm_store: LTMStore, ra_config: ResearchAgentConfig | None = None):
    return functools.partial(external_search, llm=llm, ltm_store=ltm_store, ra_config=ra_config)
