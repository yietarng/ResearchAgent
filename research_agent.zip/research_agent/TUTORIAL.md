# Research Agent — Tutorial Guide

A multi-agent research system built on LangGraph. It routes queries through
specialist agents (web search, literature, internal documents), manages
short-term and long-term memory across sessions, and synthesises findings
into a cited research summary.

---

## Table of Contents

1. [Setup](#1-setup)
2. [Quick start](#2-quick-start)
3. [Architecture overview](#3-architecture-overview)
4. [Package layout](#4-package-layout)
5. [State and reducers](#5-state-and-reducers)
6. [Graph paths in detail](#6-graph-paths-in-detail)
7. [Running the single-agent path](#7-running-the-single-agent-path)
8. [Running the multi-agent supervisor](#8-running-the-multi-agent-supervisor)
9. [Configuration reference](#9-configuration-reference)
10. [Memory system](#10-memory-system)
11. [Tools reference](#11-tools-reference)
12. [Nodes reference](#12-nodes-reference)
13. [Prompts](#13-prompts)
14. [LTM write policy](#14-ltm-write-policy)
15. [Switching to Anthropic](#15-switching-to-anthropic)
16. [Persistent STM with SQLite](#16-persistent-stm-with-sqlite)
17. [Extending the system](#17-extending-the-system)

---

## 1. Setup

### Install dependencies

```bash
cd /Users/johnny/research_agent
pip install -r requirements.txt
```

### Configure API keys

Edit `.env` inside `research_agent/`:

```env
OPENAI_API_KEY=sk-...      # required — GPT-4o + text-embedding-3-small
TAVILY_API_KEY=tvly-...    # required — web search (free tier at app.tavily.com)
# ANTHROPIC_API_KEY=sk-ant-...   # optional — only if using LLMProvider.ANTHROPIC
```

### Verify

```bash
python -c "import langgraph, langchain_openai, langchain_chroma, tavily; print('ok')"
```

---

## 2. Quick start

Scripts live inside `research_agent/`, but `from research_agent import ...`
requires the **parent** directory to be on `sys.path` (Python needs to see
`research_agent/` as a package folder, not as the current directory).

Add these two lines at the top of any script you run from inside
`research_agent/` to fix the path automatically:

```python
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
```

Save the following as `research_agent/run.py` and run it with
`python run.py` from inside `research_agent/`:

```python
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

from dotenv import load_dotenv
load_dotenv()          # finds .env in the same directory as this script

from research_agent import run_research

answer = run_research("What are the latest benchmarks comparing GPT-4o and Claude 3.5?")
print(answer)
```

```bash
cd /Users/johnny/research_agent
python run.py
```

`load_dotenv()` with no arguments finds `.env` in the current working
directory automatically — no path argument needed.

The agent will:
1. Check long-term memory for prior knowledge on the topic
2. Run a ReAct loop — web search + LTM retrieval
3. Synthesise findings into a cited summary
4. Save the result to long-term memory for future queries

---

## 3. Architecture overview

### Three nested graph layers

```
build_supervisor_graph()                   ← outer entry point
│
├─ [regex fast-path] ─────────────────────── direct_answer  (no LLM cost)
│
└─ [research_agent] ──────────────────────── build_research_team_graph()
                                                  │
                                                  ├─ plan_research   (keyword → LLM fallback)
                                                  ├─ retrieve_ltm   (populate ltm_context)
                                                  │
                                                  ├──── LiteratureAgent  ─┐
                                                  ├──── WebAgent          ├─ parallel Send fan-out
                                                  └──── InternalDocAgent ─┘
                                                  │
                                                  ├─ merge_results
                                                  ├─ summarize
                                                  ├─ update_stm
                                                  └─ write_ltm ──► ChromaDB
```

### End-to-end data flow

```
user_request
    │
    ▼
supervisor_decide
    ├─ regex matches keywords ──────────────────────────────┐
    └─ LLM decides RESEARCH / DIRECT                        │
                                                            ▼
                                                 invoke_research_agent
                                                            │
                                               ┌────────────▼─────────────┐
                                               │     team graph           │
                                               │                          │
                                               │  plan_research           │
                                               │  (fast-path or LLM)      │
                                               │        │                 │
                                               │  retrieve_ltm            │
                                               │  ltm_context → state     │
                                               │        │                 │
                                               │  [Send fan-out]          │
                                               │  ┌─────┼─────┐          │
                                               │  Lit  Web  Int           │
                                               │  └─────┼─────┘          │
                                               │        │                 │
                                               │  merge_results           │
                                               │  summarize               │
                                               │  (deduped docs           │
                                               │   + ltm_context          │
                                               │   + stm_notes)           │
                                               │  update_stm              │
                                               │  write_ltm               │
                                               └────────────┬─────────────┘
                                                            │
                                               citations appended
                                                            │
                                                            ▼
                                                       agent_result
```

### Two-layer memory

| Layer | Scope | Backend | Cap | What goes in |
|-------|-------|---------|-----|-------------|
| STM | Per `thread_id` session | LangGraph checkpointer | 20 notes | Agent notes, Q→A pairs |
| LTM | Cross-session, persistent | ChromaDB `./chroma_db/` | Unlimited (deduped) | Research summaries, benchmarks, user preferences, references |

---

## 4. Package layout

```
research_agent/
├── .env                      ← API keys
├── requirements.txt
├── TUTORIAL.md
│
├── __init__.py               ← public API (8 exports)
├── config.py                 ← ResearchAgentConfig dataclass + enums
├── state.py                  ← AgentState TypedDict + reducers
├── prompts.py                ← all 6 LLM prompts
├── graph.py                  ← single-agent sequential graph + run_research()
│
├── supervisor/
│   ├── router.py             ← regex fast-path: route_to_agent()
│   ├── supervisor_graph.py   ← build_supervisor_graph()
│   └── supervisor_state.py   ← SupervisorState TypedDict
│
├── team/
│   ├── research_supervisor.py ← build_research_team_graph() + plan/fan-out/merge
│   ├── web_agent.py           ← ReAct: web_search + LTM + STM
│   ├── literature_agent.py    ← ReAct: LTM tools only
│   └── internal_doc_agent.py  ← ReAct: separate internal LTM collection
│
├── nodes/                    ← individual nodes used in the single-agent graph
│   ├── retrieve_stm.py
│   ├── retrieve_ltm.py
│   ├── external_search.py    ← ReAct agent node
│   ├── summarize.py
│   ├── update_stm.py
│   ├── write_ltm.py
│   └── return_to_supervisor.py
│
├── memory/
│   ├── ltm.py                ← LTMStore: ChromaDB wrapper with dedup
│   └── stm.py                ← STMStore: read-only façade over LangGraph state
│
├── tools/
│   ├── ltm_tools.py          ← RetrieveLTMTool + StoreLTMTool
│   ├── stm_tools.py          ← build_stm_tools() closure factory
│   ├── web_search.py         ← WebSearchTool (Tavily)
│   └── rag_tool.py           ← deprecated stub (use ltm_tools instead)
│
└── utils/
    ├── embeddings.py         ← build_llm() + get_embeddings_model()
    └── ltm_policy.py         ← should_store_in_ltm() write gate
```

### Public API (`__init__.py`)

```python
from research_agent import (
    AgentState,              # shared TypedDict state
    default_state,           # empty state factory
    ResearchAgentConfig,     # all config in one dataclass
    STMBackend,              # MEMORY | SQLITE
    LLMProvider,             # OPENAI | ANTHROPIC
    run_research,            # single-agent convenience function
    build_supervisor_graph,  # full multi-agent entry point
    build_research_team_graph,  # team graph without supervisor wrapper
)
```

---

## 5. State and reducers

All agents share a single `AgentState` TypedDict. LangGraph applies a
**reducer** whenever a node returns an update for a field — reducers
control how updates are merged into the current state.

```python
class AgentState(TypedDict):
    user_query:        str                              # plain — set once
    research_result:   str                              # plain — last write wins
    current_plan:      str                              # plain — last write wins
    retrieved_docs:    Annotated[list, operator.add]    # accumulates across nodes
    citations:         Annotated[list, operator.add]    # accumulates across nodes
    intermediate_notes:Annotated[list, operator.add]    # audit trail
    stm_notes:         Annotated[list, _capped_add]     # append, max 20
    ltm_context:       Annotated[list, _last_write_wins] # replace, not append
```

### Why `_last_write_wins` on `ltm_context`

When the team graph fans out in parallel, each sub-agent runs as a
compiled sub-graph. LangGraph returns the **full final state** of each
sub-graph back to the parent — not just the delta. With `operator.add`,
the LTM context retrieved before the fan-out would be multiplied by the
number of agents running (3×). `_last_write_wins` prevents this by always
taking the latest value rather than appending:

```python
def _last_write_wins(_: list, b: list) -> list:
    return b   # always take the incoming update
```

### `_capped_add` on `stm_notes`

STM notes grow unboundedly without a cap. `_capped_add` appends new notes
then trims to the most recent 20:

```python
def _capped_add(a: list, b: list) -> list:
    return (a + b)[-20:]
```

---

## 6. Graph paths in detail

### Single-agent path (`graph.py`)

Sequential — each node runs once in order:

```
START
  → retrieve_stm         read prior session context into intermediate_notes
  → retrieve_ltm         semantic search → write ltm_context to state
  → external_search      ReAct loop: web_search + retrieve/store LTM + read/write STM
  → summarize            LLM synthesis using retrieved_docs + ltm_context + stm_notes
  → update_stm           write compact "Q: ... → summary..." note to stm_notes
  → write_ltm            persist research_result to ChromaDB (force_store=True)
  → return_to_supervisor append citations list to research_result string
END
```

### Team graph (`team/research_supervisor.py`)

Fan-out — sub-agents run in parallel via LangGraph's `Send` API:

```
START
  → plan_research      keyword regex → LLM fallback; writes current_plan
  → retrieve_ltm       semantic search → ltm_context in state before fan-out
  → [conditional edge] route_research_tasks() returns list[Send]
       ├─ Send("literature_agent", state)   ─┐
       ├─ Send("web_agent", state)           ├─ parallel, same state snapshot
       └─ Send("internal_doc_agent", state) ─┘
  → merge_results      sync barrier; logs doc counts
  → summarize          deduped retrieved_docs + ltm_context + stm_notes → LLM
  → update_shared_stm
  → write_shared_ltm
END
```

**Agent selection logic in `plan_research`:**

1. `_fast_plan()` checks the query against keyword patterns:
   - `literature` — paper, arxiv, survey, academic, journal, preprint, citation
   - `web` — news, blog, recent, latest, web, benchmark, release
   - `internal` — internal, document, wiki, confluence, notion, playbook
2. If any patterns match, those agents are selected with no LLM call.
3. If nothing matches, the LLM picks from the three options.
4. If the LLM returns nothing recognisable, `web_agent` is the fallback.

### Supervisor (`supervisor/supervisor_graph.py`)

```
START
  → supervisor_decide   regex (router.py) → LLM if ambiguous
  → [conditional edge]  reads agent_to_invoke from state
       ├─ research_agent   invokes team graph; appends citations to result
       └─ direct_answer    single LLM call; no research
  → format_result       sets is_complete=True
END
```

**Routing tiers:**

| Tier | Condition | LLM cost |
|------|-----------|----------|
| Regex fast-path | Query matches patterns: `search`, `find`, `survey`, `papers?`, `recent`, `latest`, `study`, `research`, `literature`, `retrieve`, `summar\w+` | Zero |
| LLM fallback | Regex returned `direct_answer` (ambiguous) | 1 LLM call |

**State boundary:** The supervisor uses `SupervisorState`; the team graph
uses `AgentState`. Only `user_request` → `user_query` crosses the boundary,
and `research_result` + `citations` come back.
Team graph thread IDs are namespaced as `"team_{thread_id}"` to avoid
checkpointer key collisions with the supervisor.

---

## 7. Running the single-agent path

`run_research()` is the simplest entry point — no supervisor, no fan-out:

```python
from dotenv import load_dotenv
load_dotenv()  # finds .env in research_agent/

from research_agent import run_research

# Basic query
result = run_research("Explain retrieval-augmented generation")
print(result)

# Multi-turn session — STM carries context between calls
result1 = run_research("What is LoRA fine-tuning?", thread_id="my-session")
result2 = run_research("How does it compare to full fine-tuning?", thread_id="my-session")
# Second query sees the first query's summary in STM
```

Build the graph directly for more control:

```python
from research_agent import build_research_graph, ResearchAgentConfig, default_state

config = ResearchAgentConfig(ltm_top_k=8, ltm_relevance_threshold=0.5)
graph = build_research_graph(config)

result = graph.invoke(
    {**default_state(), "user_query": "Summarise transformer attention mechanisms"},
    config={"configurable": {"thread_id": "t1"}},
)
print(result["research_result"])
print(result["citations"])
```

---

## 8. Running the multi-agent supervisor

`build_supervisor_graph()` is the full entry point — routing, team fan-out,
memory, synthesis:

```python
from dotenv import load_dotenv
load_dotenv()  # finds .env in research_agent/

from research_agent import build_supervisor_graph

graph = build_supervisor_graph()

# Research query — fans out to specialist agents
result = graph.invoke(
    {"user_request": "Find recent papers on speculative decoding for LLMs"},
    config={"configurable": {"thread_id": "session-1"}},
)
print(result["agent_result"])

# Conversational query — answered directly, zero sub-agent cost
result = graph.invoke(
    {"user_request": "What is 2 + 2?"},
    config={"configurable": {"thread_id": "session-1"}},
)
print(result["agent_result"])
```

Use the team graph directly (without the supervisor routing layer):

```python
from research_agent import build_research_team_graph, default_state

graph = build_research_team_graph()
result = graph.invoke(
    {**default_state(), "user_query": "Latest benchmarks for RAG vs fine-tuning"},
    config={"configurable": {"thread_id": "t1"}},
)
print(result["research_result"])
```

---

## 9. Configuration reference

All settings live in `ResearchAgentConfig`. Every graph builder accepts an
optional `config` argument.

```python
from research_agent import ResearchAgentConfig, STMBackend, LLMProvider

config = ResearchAgentConfig(
    # ── LLM ───────────────────────────────────────────────────────────────
    llm_provider=LLMProvider.OPENAI,    # or LLMProvider.ANTHROPIC
    llm_model="gpt-4o",
    llm_temperature=0.0,

    # ── Embeddings (always OpenAI — Anthropic has no embeddings API) ──────
    embedding_model="text-embedding-3-small",

    # ── Shared LTM  (web agent + literature agent) ────────────────────────
    ltm_collection_name="research_ltm",
    ltm_persist_directory="./chroma_db",
    ltm_top_k=5,                  # documents returned per retrieval call
    ltm_relevance_threshold=0.4,  # minimum cosine similarity to include a doc

    # ── Internal documents LTM (separate ChromaDB collection) ─────────────
    internal_ltm_collection_name="internal_docs",
    internal_ltm_persist_directory="./chroma_db",

    # ── STM backend ───────────────────────────────────────────────────────
    stm_backend=STMBackend.MEMORY,      # lost on process exit
    sqlite_path="./research_stm.db",    # only used when stm_backend=SQLITE

    # ── Web search ────────────────────────────────────────────────────────
    tavily_api_key_env="TAVILY_API_KEY",  # env var name (not the key itself)
)

from research_agent import build_supervisor_graph
graph = build_supervisor_graph(config=config)
```

---

## 10. Memory system

### Long-term memory — `memory/ltm.py`

`LTMStore` wraps ChromaDB with a clean four-method interface so the
backend can be swapped (FAISS, Qdrant, pgvector) by subclassing.

| Method | What it does |
|--------|-------------|
| `retrieve(query, k)` | Semantic similarity search; filters by `ltm_relevance_threshold`; returns empty list on new/empty collections |
| `store(content, metadata)` | Deduplicates via SHA-256 `content_hash` in metadata; returns existing ID if duplicate |
| `delete(doc_id)` | Remove a document by ID |
| `format_docs_for_prompt(docs)` | Formats as `[LTM 1] (source): content` for prompt injection |

**Deduplication** is persistent — the content hash is stored as a ChromaDB
metadata field and checked on every `store()` call, so identical content
written across different sessions is stored only once.

**What gets stored automatically:** The `write_ltm` node runs after every
`summarize` and persists the full research result. It bypasses the keyword
signal gate (`force_store=True`) and is only blocked by the 80-character
length floor.

**Reading and writing LTM from your own code:**

```python
from dotenv import load_dotenv
load_dotenv()  # finds .env in research_agent/

from research_agent import ResearchAgentConfig
from research_agent.memory.ltm import LTMStore
from research_agent.utils.embeddings import get_embeddings_model

config = ResearchAgentConfig()
ltm = LTMStore(config, get_embeddings_model(config))

# Search
docs = ltm.retrieve("transformer attention mechanisms")
for doc in docs:
    print(doc.page_content[:200])
    print(doc.metadata)

# Store manually (force_store bypasses keyword gate)
doc_id = ltm.store(
    "GPT-4o achieves 88.7% on MMLU as of May 2024.",
    metadata={"source": "manual", "force_store": True},
)

# Delete
ltm.delete(doc_id)
```

### Short-term memory — `memory/stm.py`

STM is the LangGraph checkpointer state scoped to a `thread_id`. It is
not a separate store — it IS the graph state, persisted by the checkpointer
between invocations on the same thread.

`STMStore` is a stateless read-only helper with three methods:

| Method | Returns |
|--------|---------|
| `get_notes(state)` | `list[str]` — all current notes |
| `get_plan(state)` | `str` — current research plan |
| `format_for_prompt(state)` | Formatted string for injection into prompts |

Agents write to STM using the `write_stm` tool (which appends to
`_pending`); the calling node includes the pending list in its return dict
under `"stm_notes"`, and the `_capped_add` reducer persists it.

**Multi-turn sessions with STM:**

```python
for query in [
    "What is RAG?",
    "What are its limitations?",
    "How does it compare to fine-tuning?"
]:
    result = run_research(query, thread_id="my-session")
    print(result)
    print("---")
# Each query sees the previous query's summary in STM context
```

---

## 11. Tools reference

Each ReAct agent receives a set of tools at construction time. All four
tool types are available to every sub-agent.

### `RetrieveLTMTool` — `retrieve_long_term_memory`

Searches long-term memory for prior knowledge.

```
Input:  natural-language query string
Output: formatted prior findings from ChromaDB
```

Agents are instructed to call this **before** web search to avoid
re-researching known topics.

### `StoreLTMTool` — `store_long_term_memory`

Saves a finding to long-term memory.

```
Input:  content (str), source (str, optional), tags (comma-separated str, optional)
Output: "Stored in LTM (id=...)" or rejection reason
```

Passes through `should_store_in_ltm()` before writing. Agents are prompted
to use this only for: survey results, benchmarks, user preferences,
important references — not raw tool outputs or intermediate notes.

### `read_stm` / `write_stm` — `build_stm_tools(state)`

**Closure factory** — creates fresh tool instances per node invocation,
capturing the current state snapshot:

```python
read_stm, write_stm, stm_writes = build_stm_tools(state)
# ... agent runs and may call write_stm("found X") ...
return {"stm_notes": stm_writes, ...}   # persisted via _capped_add reducer
```

`read_stm` supports three keys: `stm_notes`, `current_plan`, `user_query`.

`write_stm` truncates notes to 200 characters and accumulates them in a
closure-local list; nothing is written to the graph state until the
calling node returns.

### `WebSearchTool` — `web_search`

Tavily-backed web search. Reads the API key from the env var named by
`config.tavily_api_key_env` (default `"TAVILY_API_KEY"`).

```
Input:  natural-language search query
Output: up to 5 result snippets with titles, URLs, and 300-char content previews
```

---

## 12. Nodes reference

All nodes in `nodes/` are used by the single-agent `build_research_graph`.
The team graph reuses `retrieve_ltm`, `summarize`, `update_stm`, and
`write_ltm` directly.

All builder functions return `functools.partial` with LTM/LLM dependencies
pre-bound, keeping node signatures LangGraph-compatible.

| Node | Builder | Key behaviour |
|------|---------|---------------|
| `retrieve_stm` | plain function | Formats STM into `intermediate_notes`; no state writes |
| `retrieve_ltm` | `build_retrieve_ltm(ltm_store)` | Writes `ltm_context`; empty-collection safe |
| `external_search` | `build_external_search(llm, ltm_store, ra_config)` | Full ReAct loop; citations extracted from `ai`/`tool` messages only |
| `summarize` | `build_summarize(llm)` | Deduplicates `retrieved_docs` with `dict.fromkeys()` before building prompt |
| `update_stm` | plain function | Writes `"Q: {query[:80]} → {result[:200]}"` note to `stm_notes` |
| `write_ltm` | `build_write_ltm(ltm_store)` | `force_store=True` — always stores if length ≥ 80 chars |
| `return_to_supervisor` | plain function | Appends `citations` to `research_result`; single-agent path only |

---

## 13. Prompts

All prompts live in `prompts.py` and are imported by nodes/agents. Each
prompt is scoped to one role and explicitly names the tools available.

### `RESEARCH_PROMPT` — used by `external_search` (single-agent)

Structured in three phases: before (read STM + LTM), during (search +
verify), after (write STM + store LTM). Explicitly names all 5 tools:
`read_stm`, `retrieve_long_term_memory`, `web_search`, `write_stm`,
`store_long_term_memory`.

### `SUPERVISOR_PROMPT` — used by `supervisor_decide` (LLM fallback only)

Simple routing instruction: decide RESEARCH vs DIRECT. Only invoked when
the regex fast-path returns `direct_answer` (ambiguous cases).

### `SUMMARIZER_PROMPT` — used by `summarize`

Template with four slots:

```
{stm_notes}      — last 10 session notes
{ltm_context}    — prior knowledge from ChromaDB
{user_query}     — the original question
{retrieved_docs} — deduplicated docs from all agents
```

### `LITERATURE_AGENT_PROMPT` — used by `literature_search`

Instructs the agent to use `retrieve_long_term_memory` for academic papers,
preprints, and surveys. Explicitly asks it to `store_long_term_memory` for
important discoveries.

### `WEB_AGENT_PROMPT` — used by `web_search_node`

Before/during/after structure matching the research prompt. Instructs the
agent to check LTM first, run `web_search`, then write session notes and
store reusable benchmarks/references.

### `INTERNAL_DOC_AGENT_PROMPT` — used by `internal_doc_search`

Same before/during/after structure. Instructs the agent to search internal
documents via `retrieve_long_term_memory` on the internal collection, write
STM notes, and store important document references to LTM.

---

## 14. LTM write policy

`utils/ltm_policy.py` gates agent-initiated writes via `StoreLTMTool`.
`should_store_in_ltm(content, source, metadata)` returns `(bool, StorageDecision)`.

**Checks applied in order:**

| Check | Blocks when | Decision |
|-------|-------------|----------|
| Length | `len(content.strip()) < 80` | `SKIP_TOO_SHORT` |
| Signal keywords | None of 7 words present AND `force_store` not set | `SKIP_NO_SIGNAL` |
| Otherwise | — | `STORE` |

**Signal keywords** (intentionally narrow — common words removed):
`survey`, `benchmark`, `interest`, `prefer`, `reference`, `finding`, `conclusion`

**`force_store=True`** in metadata bypasses the keyword check. The
`write_ltm` node always passes this, so research results are stored
regardless of content. Agent tool calls do not set it — agents must write
content that matches the signal keywords.

**Deduplication** happens inside `LTMStore.store()`, not here. A SHA-256
content hash is stored as metadata and checked against ChromaDB before
every insert.

---

## 15. Switching to Anthropic

```bash
pip install langchain-anthropic
```

Add to `.env`:
```env
ANTHROPIC_API_KEY=sk-ant-...
```

```python
from dotenv import load_dotenv
load_dotenv()  # finds .env in research_agent/

from research_agent import ResearchAgentConfig, LLMProvider, build_supervisor_graph

config = ResearchAgentConfig(
    llm_provider=LLMProvider.ANTHROPIC,
    llm_model="claude-opus-4-8",     # or claude-sonnet-4-6, claude-haiku-4-5-20251001
    llm_temperature=0.0,
)
graph = build_supervisor_graph(config=config)
result = graph.invoke(
    {"user_request": "Summarise recent work on long-context LLMs"},
    config={"configurable": {"thread_id": "t1"}},
)
print(result["agent_result"])
```

> Embeddings always use OpenAI (`text-embedding-3-small`) regardless of
> `llm_provider` — Anthropic does not offer an embeddings API.

`build_llm()` in `utils/embeddings.py` handles the branching with a lazy
import so `langchain-anthropic` is only required when actually used.

---

## 16. Persistent STM with SQLite

By default, STM is in-memory and cleared when the process exits.
To persist session history across restarts:

```bash
pip install langgraph-checkpoint-sqlite
```

```python
from research_agent import ResearchAgentConfig, STMBackend, run_research

config = ResearchAgentConfig(
    stm_backend=STMBackend.SQLITE,
    sqlite_path="./research_stm.db",
)

# First run — result stored in SQLite
run_research("What is mixture-of-experts?", thread_id="t1", config=config)

# Second run, even after restart — STM context is restored from SQLite
run_research("What are the scaling advantages?", thread_id="t1", config=config)
```

SQLite and in-memory backends are interchangeable — swap `stm_backend`
without changing anything else.

---

## 17. Extending the system

### Add a new specialist agent

1. Create `research_agent/team/my_agent.py` following the pattern in
   `literature_agent.py` — a node function and a `build_my_agent_graph()`.
2. Add keyword patterns to `_PLAN_SIGNALS` in `research_supervisor.py`.
3. Register and wire in `build_research_team_graph()`:

```python
# In build_research_team_graph():
my_graph = build_my_agent_graph(config, llm, ltm_store)
graph.add_node("my_agent", my_graph.invoke)
graph.add_edge("my_agent", "merge_results")
# route_research_tasks() will pick it up via _PLAN_SIGNALS
```

### Pre-populate the internal document collection

The `InternalDocAgent` reads from a separate ChromaDB collection
(`internal_docs`). Ingest your documents before running:

```python
from dotenv import load_dotenv
load_dotenv()  # finds .env in research_agent/

import dataclasses
from research_agent import ResearchAgentConfig
from research_agent.memory.ltm import LTMStore
from research_agent.utils.embeddings import get_embeddings_model

config = ResearchAgentConfig()
internal_config = dataclasses.replace(
    config,
    ltm_collection_name=config.internal_ltm_collection_name,
    ltm_persist_directory=config.internal_ltm_persist_directory,
)
internal_ltm = LTMStore(internal_config, get_embeddings_model(config))

# Ingest a file
with open("runbook.txt") as f:
    internal_ltm.store(f.read(), metadata={"source": "runbook.txt", "force_store": True})

# Ingest multiple files
import pathlib
for path in pathlib.Path("docs/").glob("*.txt"):
    internal_ltm.store(
        path.read_text(),
        metadata={"source": str(path), "force_store": True},
    )
```

### Use a custom Tavily env var name

```python
config = ResearchAgentConfig(tavily_api_key_env="MY_TAVILY_KEY")
```

Set `MY_TAVILY_KEY=tvly-...` in your environment or `.env`.

### Swap the vector store

`LTMStore` is designed for subclassing. Override `retrieve`, `store`, and
`delete` to use FAISS, Qdrant, pgvector, or any other backend:

```python
from research_agent.memory.ltm import LTMStore

class QdrantLTMStore(LTMStore):
    def __init__(self, config, embeddings):
        # initialise Qdrant client instead of Chroma
        ...

    def retrieve(self, query, k=None):
        ...

    def store(self, content, metadata=None):
        ...
```

Pass your subclass instance directly to any graph builder that accepts
`ltm_store`.
